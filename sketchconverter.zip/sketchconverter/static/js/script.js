document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('file');
    const fileNameDisplay = document.getElementById('file-name');
    const dropArea = document.getElementById('dropArea');
    const form = document.querySelector('form');
    
    // Prevent default drag behaviors everywhere
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        document.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    // Highlight drop area when item is dragged over it
    ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, unhighlight, false);
    });

    function highlight(e) {
        preventDefaults(e);
        dropArea.classList.add('active');
    }

    function unhighlight(e) {
        preventDefaults(e);
        dropArea.classList.remove('active');
    }

    // Handle dropped files
    dropArea.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length) {
            fileInput.files = files;
            fileNameDisplay.textContent = files[0].name;
            
            // Create preview if it's an image
            if (files[0].type.match('image.*')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('filePreview');
                    preview.innerHTML = `
                        <div class="preview-image">
                            <img src="${e.target.result}" alt="Preview">
                        </div>
                    `;
                };
                reader.readAsDataURL(files[0]);
            }
        }
    }

    // Handle file input change
    fileInput.addEventListener('change', function() {
        if (this.files && this.files[0]) {
            fileNameDisplay.textContent = this.files[0].name;
            
            // Create preview if it's an image
            if (this.files[0].type.match('image.*')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('filePreview');
                    preview.innerHTML = `
                        <div class="preview-image">
                            <img src="${e.target.result}" alt="Preview">
                        </div>
                    `;
                };
                reader.readAsDataURL(this.files[0]);
            }
        } else {
            fileNameDisplay.textContent = 'No file selected';
            document.getElementById('filePreview').innerHTML = '';
        }
    });
});
